// test_case_spec.js

// Cypress Test Case

describe('Sample Test Suite', () => {
  it('Visits the Cypress website', () => {
    cy.visit('https://www.cypress.io');
    cy.contains('JavaScript End to End Testing Framework');
  });

  it('Checks the navigation bar', () => {
    cy.get('nav').should('exist');
  });
});