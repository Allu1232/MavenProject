// supporting_functions.js

// Cypress Supporting Functions

function login(username, password) {
  cy.get('#username').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
}

module.exports = { login };