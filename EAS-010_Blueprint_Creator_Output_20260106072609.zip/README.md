# Project Overview

This project uses Cypress for end-to-end testing. The test cases are located in the `tests` directory, and supporting functions are in the `support` directory.

## Setup

1. Install Node.js.
2. Run `npm install` to install Cypress and other dependencies.

## Running Tests

Execute `npx cypress open` to start the Cypress Test Runner.

## File Structure

- `tests/test_case_example.js`: Contains example test cases.
- `support/support_function.js`: Contains supporting functions for test cases.