// Example support function

function helperFunction() {
  return 'This is a helper function';
}

module.exports = { helperFunction };